package com.example.B2BHotelBookingSystem.controllers;


public abstract class BaseController {
    protected static final String REDIRECT = "redirect:";
}
